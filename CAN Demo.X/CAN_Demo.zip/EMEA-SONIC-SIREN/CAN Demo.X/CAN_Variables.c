/******************************************************************
 * @file CAN_VARIABLES.c
 * @author Martyn Carribine
 * @date 06/02/2019
 * @brief C files associated with the Variables header file
 * Copyright (c) ECCO Safety Group
 * 
 ******************************************************************/
#include "SYS_H.h"
#include "CAN_Variables.h"


