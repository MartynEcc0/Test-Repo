#ifndef UN3_Variables
#define	UN3_Variables
/******************************************************************
 * @file CAN_VARIABLES.c
 * @author Martyn Carribine
 * @date 06/02/2019
 * @brief All application variances can be configured here
 * Copyright (c) ECCO Safety Group
 * 
 ******************************************************************/





#endif /* Variables */