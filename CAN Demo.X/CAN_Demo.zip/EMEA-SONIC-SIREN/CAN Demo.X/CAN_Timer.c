/******************************************************************
 * @file CAN_Timer.c
 * @author Martyn Carribine
 * @date 06/02/2019
 * @brief Controls all the timers based on the 1mS tick.
 * Copyright (c) ECCO Safety Group
 * 
 ******************************************************************/
#include "CFG_CPU.h"
#include "CAN_Timer.h"
#include "SYS_Message.h"
#include "CAN_Variables.h"
#include "CAN_CAN.h"

typedef struct timer_t
{
    uint16_t timer;
    uint16_t timeout;
    void (*onTimeout)(void);
}
timer_t;

static timer_t timers[NUM_TIMERS] = 
{
    { 0, 0, debugTimer},
};

/**********************************************************************//*
* FUNCTION     	: systemTickInit
* AUTHOR       	: Martyn Carribine
* INPUTS        : void
* OUTPUTS      	: none
* RETURNS      	: void
* DESCRIPTION  	: Initialises a one millisecond 'tick' timer 
*
*************************************************************************/

void systemTickInit(void)
{
//     Use timer 6 to generate 1ms Interrupt tick
    TICK_TIMER_COUNT = TICK_TIMER_RESET;
    TICK_TIMER = 0;
    
#ifdef PLL_ENABLED
    TICK_TIMER_CONFIG = 0b00011111;   // 1:4 Post-scale
#else  // PLL_ENABLED
    TICK_TIMER_CONFIG = 0b00000111;   // 1:1 Post-scale
#endif // PLL_ENABLED    
    
    TICK_TIMER_INT_FLAG = 0;
    TICK_TIMER_INT_ENABLE = 1;
}

/**********************************************************************//*
* FUNCTION     	: timerRoutine
* AUTHOR       	: Martyn Carribine
* INPUTS        : void
* OUTPUTS      	: none
* RETURNS      	: void
* DESCRIPTION  	: updates all timers at the tick rate and executes the appropriate function on timeout
*
*************************************************************************/

void timerRoutine(void)
{

    uint8_t i;
    //reset the interrupt flag
    //process the tick timer
    for (i = 0; i < NUM_TIMERS; i++)
    {
        if (timers[i].timer > 0)
        {
            timers[i].timer--;

            if (0 == timers[i].timer)
            {
                timers[i].onTimeout();
            }
        }
    }

}
/**********************************************************************//*
* FUNCTION     	: setTimer
* AUTHOR       	: Martyn Carribine
* INPUTS        : void
* OUTPUTS      	: none
* RETURNS      	: void
* DESCRIPTION  	: Loads a timer
*
*************************************************************************/

void setTimer(timerIdx_t timerIdx, uint16_t timeout)
{
    timer_t* pTimer = timers + timerIdx;

    // disable timer interrupt while setting timeout value
    TICK_TIMER_INT_ENABLE = 0;
    pTimer->timer = timeout;
    pTimer->timeout = timeout;
    TICK_TIMER_INT_ENABLE = 1;
}
/**********************************************************************//*
* FUNCTION     	: resetTimer
* AUTHOR       	: Martyn Carribine
* INPUTS        : void
* OUTPUTS      	: none
* RETURNS      	: void
* DESCRIPTION  	: resets a timer to its default value
*
*************************************************************************/

void resetTimer(timerIdx_t timerIdx)
{
    timer_t* pTimer = timers + timerIdx;

    // disable timer interrupt while setting timeout value
    TICK_TIMER_INT_ENABLE = 0;
    pTimer->timer = pTimer->timeout;
    TICK_TIMER_INT_ENABLE = 1;
}

/**********************************************************************//*
* FUNCTION     	: stopTimer
* AUTHOR       	: Martyn Carribine
* INPUTS        : void
* OUTPUTS      	: none
* RETURNS      	: void
* DESCRIPTION  	: Stops a timer
*
*************************************************************************/

void stopTimer(timerIdx_t timerIdx)
{
    // disable timer interrupt while setting timeout value
    TICK_TIMER_INT_ENABLE = 0;
    timers[timerIdx].timer = 0;
    TICK_TIMER_INT_ENABLE = 1;
}

/**********************************************************************//*
* FUNCTION     	: debugTimer
* AUTHOR       	: Martyn Carribine
* INPUTS        : void
* OUTPUTS      	: none
* RETURNS      	: void
* DESCRIPTION  	: stops the DALI tick time from turning the relay off while replying to RSMS command
*
*************************************************************************/

void debugTimer(void)
{
    setTimer(DEBUG_TIMER, DEBUG_TICK);
    LATEbits.LATE2 = !LATEbits.LATE2;
    eccoNetCanMessage.frame.dlc = 8;
    eccoNetCanMessage.frame.data0 = 0;
    eccoNetCanMessage.frame.data1 = 1;
    eccoNetCanMessage.frame.data2 = 2;
    eccoNetCanMessage.frame.data3 = 3;
    eccoNetCanMessage.frame.data4 = 4;
    eccoNetCanMessage.frame.data5 = 5;
    eccoNetCanMessage.frame.data6 = 6;
    eccoNetCanMessage.frame.data7 = 7;
    CAN_transmit((uCAN_MSG_t*)&eccoNetCanMessage);
}

